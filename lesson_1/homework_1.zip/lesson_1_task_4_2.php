<?php

$h1 = "Информация обо мне";
$title = "Главная страница - страница обо мне";
$date = date('Y');
$imageName = rand(1,2);

include "site.php";